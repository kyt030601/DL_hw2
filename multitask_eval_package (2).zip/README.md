# Unified Multi-Task Model

This repository contains a lightweight multi-task image understanding system supporting Segmentation, Detection, and Classification.

## Evaluation

```bash
python eval.py --weights your_model.pt --data_root data --tasks all
```
