import sys, os
sys.path.append(os.path.dirname(__file__))
print('Dummy eval')